package com.pradipta.pendaftaranseminar

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etEmail = findViewById<TextInputEditText>(R.id.etEmail)
        val etPassword = findViewById<TextInputEditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvRegister = findViewById<TextView>(R.id.tvRegister)

        btnLogin.setOnClickListener {
            val emailInput = etEmail.text.toString()
            val passwordInput = etPassword.text.toString()

            // Ambil data dari SharedPreferences (data yang didaftarkan di RegisterActivity)
            val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
            val savedEmail = sharedPref.getString("EMAIL", "admin@utb.ac.id") // Default UTB
            val savedPassword = sharedPref.getString("PASSWORD", "12345")
            val savedName = sharedPref.getString("NAME", "Mahasiswa UTB")

            // Validasi login
            if (emailInput == savedEmail && passwordInput == savedPassword) {
                // Berhasil login, lanjut ke Halaman Utama
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("USER_NAME", savedName)
                startActivity(intent)
                finish()
            } else {
                // Tampilkan error jika login gagal
                Toast.makeText(this, "Email atau Password Salah!", Toast.LENGTH_SHORT).show()
            }
        }

        tvRegister.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }
}