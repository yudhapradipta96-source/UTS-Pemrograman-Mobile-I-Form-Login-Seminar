package com.pradipta.pendaftaranseminar

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val etRegName = findViewById<TextInputEditText>(R.id.etRegName)
        val etRegEmail = findViewById<TextInputEditText>(R.id.etRegEmail)
        val etRegPassword = findViewById<TextInputEditText>(R.id.etRegPassword)
        val btnRegister = findViewById<Button>(R.id.btnRegister)
        val tvLogin = findViewById<TextView>(R.id.tvLogin)

        btnRegister.setOnClickListener {
            val name = etRegName.text.toString()
            val email = etRegEmail.text.toString()
            val password = etRegPassword.text.toString()

            if (name.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {
                // Simpan data ke SharedPreferences
                val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
                with(sharedPref.edit()) {
                    putString("NAME", name)
                    putString("EMAIL", email)
                    putString("PASSWORD", password)
                    apply()
                }

                Toast.makeText(this, "Registrasi Berhasil! Selamat Datang, $name", Toast.LENGTH_SHORT).show()
                
                // Langsung masuk ke Halaman Utama (Otomatis Login)
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("USER_NAME", name)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Semua field harus diisi!", Toast.LENGTH_SHORT).show()
            }
        }

        tvLogin.setOnClickListener {
            finish() // Kembali ke Login
        }
    }
}