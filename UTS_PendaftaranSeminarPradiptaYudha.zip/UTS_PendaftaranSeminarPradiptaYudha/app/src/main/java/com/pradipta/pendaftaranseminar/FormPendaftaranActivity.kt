package com.pradipta.pendaftaranseminar

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class FormPendaftaranActivity : AppCompatActivity() {

    private lateinit var etNama: TextInputEditText
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPhone: TextInputEditText
    private lateinit var rgGender: RadioGroup
    private lateinit var spinnerSeminar: Spinner
    private lateinit var cbAgreement: CheckBox
    private lateinit var btnSubmit: Button

    private lateinit var tilNama: TextInputLayout
    private lateinit var tilEmail: TextInputLayout
    private lateinit var tilPhone: TextInputLayout

    private val seminarOptions = arrayOf(
        "Seminar Teknologi AI 2024",
        "Web Development Workshop",
        "Mobile App Design with Flutter",
        "Cyber Security Fundamentals",
        "Data Science for Beginners"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form_pendaftaran)

        initViews()
        setupSpinner()
        setupRealTimeValidation()

        btnSubmit.setOnClickListener {
            if (validateAll()) {
                showConfirmationDialog()
            }
        }
    }

    private fun initViews() {
        etNama = findViewById(R.id.etNama)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        rgGender = findViewById(R.id.rgGender)
        spinnerSeminar = findViewById(R.id.spinnerSeminar)
        cbAgreement = findViewById(R.id.cbAgreement)
        btnSubmit = findViewById(R.id.btnSubmit)

        tilNama = findViewById(R.id.tilNama)
        tilEmail = findViewById(R.id.tilEmail)
        tilPhone = findViewById(R.id.tilPhone)
    }

    private fun setupSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, seminarOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerSeminar.adapter = adapter
    }

    private fun setupRealTimeValidation() {
        etEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                validateEmail(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        etPhone.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                validatePhone(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun validateEmail(email: String): Boolean {
        return if (!email.contains("@")) {
            tilEmail.error = getString(R.string.error_email_invalid)
            false
        } else {
            tilEmail.error = null
            true
        }
    }

    private fun validatePhone(phone: String): Boolean {
        return if (!phone.startsWith("08") || phone.length < 10 || phone.length > 13 || !phone.all { it.isDigit() }) {
            tilPhone.error = getString(R.string.error_phone_invalid)
            false
        } else {
            tilPhone.error = null
            true
        }
    }

    private fun validateAll(): Boolean {
        var isValid = true

        if (etNama.text.isNullOrBlank()) {
            tilNama.error = getString(R.string.error_empty)
            isValid = false
        } else {
            tilNama.error = null
        }

        if (!validateEmail(etEmail.text.toString())) isValid = false
        if (!validatePhone(etPhone.text.toString())) isValid = false

        if (rgGender.checkedRadioButtonId == -1) {
            Toast.makeText(this, "Silakan pilih jenis kelamin", Toast.LENGTH_SHORT).show()
            isValid = false
        }

        if (!cbAgreement.isChecked) {
            Toast.makeText(this, getString(R.string.error_agreement), Toast.LENGTH_SHORT).show()
            isValid = false
        }

        return isValid
    }

    private fun showConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_title)
            .setMessage(R.string.dialog_message)
            .setPositiveButton(R.string.dialog_yes) { _, _ ->
                navigateToResult()
            }
            .setNegativeButton(R.string.dialog_no, null)
            .show()
    }

    private fun navigateToResult() {
        val intent = Intent(this, ResultActivity::class.java).apply {
            putExtra("NAMA", etNama.text.toString())
            putExtra("EMAIL", etEmail.text.toString())
            putExtra("PHONE", etPhone.text.toString())
            val genderId = rgGender.checkedRadioButtonId
            val gender = findViewById<RadioButton>(genderId).text.toString()
            putExtra("GENDER", gender)
            putExtra("SEMINAR", spinnerSeminar.selectedItem.toString())
        }
        startActivity(intent)
    }
}