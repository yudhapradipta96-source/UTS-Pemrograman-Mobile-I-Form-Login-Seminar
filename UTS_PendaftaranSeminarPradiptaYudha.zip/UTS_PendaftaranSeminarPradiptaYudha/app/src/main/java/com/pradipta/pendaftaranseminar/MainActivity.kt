package com.pradipta.pendaftaranseminar

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvWelcome = findViewById<TextView>(R.id.tvWelcome)
        val btnDaftarSeminar = findViewById<Button>(R.id.btnDaftarSeminar)

        // Ambil nama user dari intent (jika ada)
        val userName = intent.getStringExtra("USER_NAME") ?: "Mahasiswa"
        tvWelcome.text = getString(R.string.welcome_message, userName)

        btnDaftarSeminar.setOnClickListener {
            val intent = Intent(this, FormPendaftaranActivity::class.java)
            startActivity(intent)
        }
    }
}